package com.pradeep.storeapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pradeep.storeapp.dao.ProductRepository;
import com.pradeep.storeapp.domain.Product;

@Service
public class ProductServiceImpl implements IProductService {

	@Autowired
	private ProductRepository repository;

	@Override
	public Product addProduct(Product product) {
		return repository.save(product);
	}

	@Override
	public Product updateProduct(Product product) {
		// TODO Auto-generated method stub
		return repository.save(product);
	}

	@Override
	public Product findProduct(Integer id) {
		return repository.findById(id).get();
	}

	@Override
	public boolean deleteProduct(Integer id) {

		if (repository.existsById(id)) {
			repository.deleteById(id);
			return true;
		}

		return false;
	}

	@Override
	public List<Product> findAllProducts() {
		return repository.findAll();
	}

}
