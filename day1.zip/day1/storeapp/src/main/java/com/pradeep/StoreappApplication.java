package com.pradeep;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.pradeep.storeapp.dao.ProductRepository;
import com.pradeep.storeapp.domain.Product;

@SpringBootApplication
public class StoreappApplication implements CommandLineRunner {

	@Autowired
	ProductRepository productRepository;
	
	public static void main(String[] args) {
		SpringApplication.run(StoreappApplication.class, args);
	}
	
	@Override
	public void run(String... args) throws Exception {
		productRepository.save(new Product(null, "APPLE-12", "APPLE", 130000.00));
		productRepository.save(new Product(null, "GALAXY", "SAMSUNG", 110000.00));
		productRepository.save(new Product(null, "TV", "LG", 130000.00));
		productRepository.save(new Product(null, "WASHINGMACHIN", "LG", 63000.00));
		
	}

}
