package com.pradeep;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.pradeep.storeapp.domain.Product;

@RestController
public class StoreappOpenFeighClientController {

@Autowired
private ProductServiceProxy proxy;


@GetMapping("/get-product-service")
public String getProductServiceIndexPage() {
	return  proxy.index();
			
}


@GetMapping("/getallproducts")
public String getAllProducts() {
	return proxy.getAllProducts().toString();

}

@GetMapping("/get-product/{id}")
public String getAllProducts(@PathVariable("id") int id) {
	return proxy.getProductById(id).toString();
			
}
	
}
