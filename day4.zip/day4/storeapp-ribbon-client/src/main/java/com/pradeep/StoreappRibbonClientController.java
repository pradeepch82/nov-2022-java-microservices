package com.pradeep;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class StoreappRibbonClientController {

@Value("${productServiceURL:http://product-service}")	
private String productServiceURL; 	

@Autowired
private RestTemplate restTemplate;

@GetMapping("/get-product-service")
public String getProductServiceIndexPage() {
	return restTemplate.getForObject(productServiceURL, String.class);
}


@GetMapping("/getallproducts")
public String getAllProducts() {
	return restTemplate.getForObject(productServiceURL+"/products", String.class);
}

@GetMapping("/get-product/{id}")
public String getAllProducts(@PathVariable("id") int id) {
	return restTemplate.getForObject(productServiceURL+"/products/"+id, String.class);
}
	
}
