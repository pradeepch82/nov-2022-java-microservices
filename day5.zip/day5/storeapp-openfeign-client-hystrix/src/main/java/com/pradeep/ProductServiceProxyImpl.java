package com.pradeep;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.pradeep.storeapp.domain.Product;
@Service
public class ProductServiceProxyImpl implements ProductServiceProxy {

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return Arrays.asList(new Product(343,"Product","company",12000.00));
	}

	@Override
	public Product getProductById(Integer id) {
		// TODO Auto-generated method stub
		return new Product(343,"Product","company",12000.00);
	}

	@Override
	public Product addProduct(Product product) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product updateProduct(Integer id, Product product) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteProduct(Integer id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String index() {
		// TODO Auto-generated method stub
		return "Index Fallback Method";
	}

	
	
}
