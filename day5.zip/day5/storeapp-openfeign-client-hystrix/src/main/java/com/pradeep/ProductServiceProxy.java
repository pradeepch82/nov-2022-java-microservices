package com.pradeep;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.pradeep.storeapp.domain.Product;

@FeignClient(name="product-service",fallback = ProductServiceProxyImpl.class )
public interface ProductServiceProxy {

	
	 @GetMapping("/products") 
	 public List<Product> getAllProducts();
	 
	 @GetMapping("/products/{id}") 
	  public Product getProductById(@PathVariable("id")Integer id);
	 
	    @PostMapping("/products")
	    public Product addProduct(@RequestBody Product product);
	    
	    @PutMapping("/{id}")
	    public Product updateProduct(@PathVariable("id")Integer id,@RequestBody Product product);
	     
	    
	    @DeleteMapping("/{id}")
	    public  void deleteProduct(@PathVariable("id")Integer id);
	 
	 
		
		@GetMapping
		public String index();
}
