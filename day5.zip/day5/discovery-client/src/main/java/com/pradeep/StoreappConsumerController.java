package com.pradeep;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class StoreappConsumerController {

	@Autowired
	private DiscoveryClient discoveryClient;
		
	private RestTemplate restTemplate=new RestTemplate();
	
	
	@GetMapping
	public String getIndex() {
		
		String response="Welcome To Spring Cloud DiscoveryClient Example";
		
		return response;
	}
	
	
	@GetMapping("/storeapp")
	public String DemoIndex() {
		
		
		List<ServiceInstance> instances=
				discoveryClient.getInstances("product-service");
		
		for(ServiceInstance si:instances) {
			System.out.println("---------------------------------------------");
			System.out.println("Service Instance Host :"+si.getHost());	
			System.out.println("Service Instance   Id :"+si.getInstanceId());	
			System.out.println("Service Instance Port :"+si.getPort());	
			System.out.println("Service Instance URI  :"+si.getUri().toString());	
			System.out.println("Service Instance  Scheme :"+si.getScheme());
			System.out.println("Service Instance URI :"+si.getUri());
			System.out.println("---------------------------------------------");
			
			
			
		}
		
		Random r =new Random();
		
		ServiceInstance si=instances.get(r.nextInt(3));
		
		
		String serviceURL=si.getUri().toString();  //http://10.1.0.25:2222/products
		
		
		String products=restTemplate.getForObject(serviceURL, String.class);
		
		
		
		return "Products :"+products;
	}
	
	
	
	
	@GetMapping("/getproducts")
	public String getAllProducts() {
		
		
		List<ServiceInstance> instances=
				discoveryClient.getInstances("product-service");
		
		for(ServiceInstance si:instances) {
			System.out.println("---------------------------------------------");
			System.out.println("Service Instance Host :"+si.getHost());	
			System.out.println("Service Instance   Id :"+si.getInstanceId());	
			System.out.println("Service Instance Port :"+si.getPort());	
			System.out.println("Service Instance URI  :"+si.getUri().toString());	
			System.out.println("Service Instance  Scheme :"+si.getScheme());
			System.out.println("Service Instance URI :"+si.getUri());
			System.out.println("---------------------------------------------");
			
			
			
		}
		
		Random r =new Random();
		
		ServiceInstance si=instances.get(r.nextInt(3));
		
		
		String serviceURL=si.getUri()+"/products";  //http://10.1.0.25:2222/products
		
		
		String products=restTemplate.getForObject(serviceURL, String.class);
		
		
		
		return "Products :"+products;
	}
	
	
	
	
	@GetMapping("/getproducts/{productId}")
	public String getProductById(@PathVariable("productId")Integer id) {
		
		
		List<ServiceInstance> instances=
				discoveryClient.getInstances("product-service");
		
		
		
		ServiceInstance si=instances.get(0);
		
		String serviceURL=si.getUri()+"/products/"+id;
		
		String product=restTemplate.getForObject(serviceURL, String.class);
		
		
		return "Products :"+product;
	}
	
	
}
