package com.pradeep.storeapp.domain;


public class Product {


private Integer id;
private String name;
private String company;
private Double price;


public Product() {
}
public Product(Integer id, String name, String company, Double price) {
	super();
	this.id = id;
	this.name = name;
	this.company = company;
	this.price = price;
}
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getCompany() {
	return company;
}
public void setCompany(String company) {
	this.company = company;
}
public Double getPrice() {
	return price;
}
public void setPrice(Double price) {
	this.price = price;
}
@Override
public String toString() {
	return "Product [id=" + id + ", name=" + name + ", company=" + company + ", price=" + price + "]";
}

}
