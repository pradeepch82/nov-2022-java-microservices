package com.pradeep;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.pradeep.storeapp.domain.Product;

@RestController
public class StoreappRibbonClientController {

@Value("${productServiceURL:http://product-service}")	
private String productServiceURL; 	

@Autowired
private RestTemplate restTemplate;

@GetMapping("/get-product-service")
public String getProductServiceIndexPage() {
	return restTemplate.getForObject(productServiceURL, String.class);
}

@HystrixCommand(fallbackMethod = "getAllProductsFallback")
@GetMapping("/getallproducts")
public String getAllProducts() {
	return restTemplate.getForObject(productServiceURL+"/products", String.class);
}


public String getAllProductsFallback() {
	return 
			Arrays.asList(new Product(343,"Product","company",12000.00)).toString();
	
			
}


@HystrixCommand(fallbackMethod = "getProductByIdFallback")
@GetMapping("/get-product/{id}")
public String getProductById(@PathVariable("id") int id) {
	return restTemplate.getForObject(productServiceURL+"/products/"+id, String.class);
}



public String getProductByIdFallback(@PathVariable("id") int id) {
	return new Product(1111,"Dummy Object", "Dummy Company", 456.44).toString(); 
			
}




	

}
