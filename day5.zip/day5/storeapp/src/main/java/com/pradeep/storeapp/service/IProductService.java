package com.pradeep.storeapp.service;

import java.util.List;

import com.pradeep.storeapp.domain.Product;

public interface IProductService {

	Product addProduct(Product product);

	Product updateProduct(Product product);

	Product findProduct(Integer id);

	boolean deleteProduct(Integer id);

	List<Product> findAllProducts();

}
