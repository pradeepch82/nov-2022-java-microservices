package com.pradeep.storeapp.restapi;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.pradeep.storeapp.domain.Product;
import com.pradeep.storeapp.service.IProductService;

@RestController
@RequestMapping("/products")
public class ProductRestController {

    @Autowired
	IProductService productService;
	

    @GetMapping 
    public List<Product> getAllProduct(){
 	   return productService.findAllProducts();
    }

    
    
    @GetMapping("/{id}") 
    public Product getProductById(@PathVariable("id")Integer id){
 	   return productService.findProduct(id);
 	 }
     
    @ResponseStatus(code = HttpStatus.CREATED)
    @PostMapping
    public Product addProduct(@RequestBody Product product){
 	   return productService.addProduct(product);
 	}
     
    @PutMapping("/{id}")
    public Product addProduct(@PathVariable("id")Integer id,@RequestBody Product product){
 	   return productService.updateProduct(product);
 	 }
      
    
    @ResponseStatus(code = HttpStatus.NO_CONTENT)
    @DeleteMapping("/{id}")
    public  void addProduct(@PathVariable("id")Integer id){
 	       productService.deleteProduct(id);   
    
    }
    
    	
}
